/usr/sbin/alternatives \
  --install /usr/bin/lunit \
    lunit /usr/bin/lunit-5.3 \
    503 \
  ;
