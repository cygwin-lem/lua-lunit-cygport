/usr/sbin/alternatives \
  --remove \
    lunit /usr/bin/lunit-5.3 \
  ;
